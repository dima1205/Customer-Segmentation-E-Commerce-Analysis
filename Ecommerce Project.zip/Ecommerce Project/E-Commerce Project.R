# Ecommerce Project

# Installing packages
install.packages("plyr")
install.packages("ggplot2")
install.packages("scales")
install.packages("NbClust")
install.packages("magrittr")
install.packages("dplyr")
install.packages("rpart")
install.packages("rpart.plot")
library(magrittr)
library(dplyr)
library(ggplot2)
library(rpart)
library(rpart.plot)

# Select Working Directory

setwd("C:/Users/Dima/Desktop")
getwd()

# Importing dataset

data <- read.csv("Ecommerce.csv", head= TRUE,sep = ";")
View(data)
str(data)

# Data Cleaning

# First step is to check if there is any missing values in the dataset and to remove them

length(unique(data$CustomerID))
sum(is.na(data$CustomerID))
data <- subset(data,!is.na(data$CustomerID))

# Second step we can observe that the customer transactions are spread between different countries.
# Hence our analysis will be based on one geographic unit where the most of transactions have been identified, in our case it's the UK

table(data$Country)

data <- subset(data, Country == "United Kingdom")
View(data)

# Third step is to analyze the length of unique Invoices and unique Customers

length(unique(data$InvoiceNo))
length(unique(data$CustomerID))

# We identified in this case a dataset of 19857 of unique Invoices and 3950 of unique customers.

# To start calculating the frequency and recency metrics one should start distinguishing invoices with purchases from invoices with returns

data$item.return <- grepl("C", data$InvoiceNo, fixed = TRUE)
data$purchase.invoice <- ifelse(data$item.return=="TRUE",0,1)

# Creation of a Customer-level dataset

customers <- as.data.frame(unique(data$CustomerID))
names(customers) <- "CustomerID"

# RFM Analysis

# Calculating the Recency

help("as.Date")

# Converting "InvoiceDate" from factor to date type format

data$InvoiceDate <- as.Date(data$InvoiceDate,"%d/%m/%Y")
str(data)

# Adding a recency column by substracting the InvoiceDate from the (last InvoiceDate+1)

data$recency <- as.Date("2017-12-08")- as.Date(data$InvoiceDate)


# Returns will be removed to only consider the data of most recent "purchase"

purdata <- subset(data,purchase.invoice==1)

# Aggregate to obtain the number of days since most recent purchase

recency <- aggregate(recency ~ CustomerID, data=purdata,FUN=min,na.rm=TRUE)

# Add recency to customer data

customers <- merge(customers,recency,by="CustomerID",all = TRUE, sort=TRUE)
remove(recency)
str(customers)
customers$recency <- as.numeric(customers$recency)

summary(customers$recency)

# Let's plot the recency Histogram

ggplot(customers, aes(recency)) +
  geom_histogram() +
  ylab('Number of Customers') +
  theme_minimal()

# Frequency #

customer.invoices <- subset(data, select = c("CustomerID","InvoiceNo", "purchase.invoice"))
customer.invoices <- customer.invoices[!duplicated(customer.invoices), ]
customer.invoices <- customer.invoices[order(customer.invoices$CustomerID),]
row.names(customer.invoices) <- NULL

# Number of invoices/year (purchases only)
annual.invoices <- aggregate(purchase.invoice ~ CustomerID, data=customer.invoices, FUN=sum,na.rm=TRUE)
names(annual.invoices)[names(annual.invoices)=="purchase.invoice"] <- "frequency"

# Add # of invoices to customers data
customers <- merge(customers, annual.invoices, by="CustomerID", all=TRUE, sort=TRUE)
remove(customer.invoices, annual.invoices)
range(customers$frequency)
table(customers$frequency)

# Remove customers who have not made any purchases in the past year
customers <- subset(customers, frequency > 0)

summary(customers$frequency)

# Plot the Frequency metric



# Monetary Value of Customers #

# Total spent on each item on an invoice
data$Amount <- data$Quantity * data$UnitPrice

# Aggregated total sales to customer
total.sales <- aggregate(Amount ~ CustomerID, data=data, FUN=sum, na.rm=TRUE)
names(total.sales)[names(total.sales)=="Amount"] <- "monetary"

# Add monetary value to customers dataset
customers <- merge(customers, total.sales, by="CustomerID", all.x=TRUE, sort=TRUE)
remove(total.sales)

# Identify customers with negative monetary value numbers, as they were presumably returning purchases from the preceding year
hist(customers$monetary)
customers$monetary <- ifelse(customers$monetary < 0, 0, customers$monetary) # reset negative numbers to zero
hist(customers$monetary)

# Identify the right numbers of customers segments

set.seed(415)
cluster <- kmeans(scale(customers[,2:4]), 3 , nstart = 1)

# Attaching the results to customers dataset

customers$clusters <- as.factor(cluster$clusters)

# Let's identify high value, Medium Value, Low Value customers

KMeans_Results <- customers %>%
  group_by(clusters) %>%
  summarise('Number of Users' = n(),
            'Recency Mean' = round(mean(recency)),
            'Frequency Mean' = scales::comma(round(mean(frequency))),
            'Monetary Value Mean' = scales::dollar(round(mean(monetary))),
            'Cluster Revenue' = scales::dollar(sum(monetary))
  )

View(KMeans_Results)

Cluster_size_visz <- ggplot(KMeans_Results, aes(clusters, `Number of Users`)) +
  geom_text(aes(label = `Number of Users`), vjust = -0.3) +
  geom_bar(aes(fill= clusters), stat='identity') +
  ggtitle('Number of Users per Cluster') + 
  xlab("Cluster Number") +
  theme_classic()
print(Cluster_size_visz)

# Hierarchical Clustering

Cluster_3_Tree <- customers %>%
  filter(clusters == '1') %>%
  select(frequency, monetary, recency)

fit_tree <-rpart(monetary ~ ., 
                 data=Cluster_3_Tree,
                 method = 'anova', 
                 control= rpart.control(cp=0.0127102))

rpart.plot(fit_tree, type=1,extra=1, box.palette=c("gray","lightblue"))

